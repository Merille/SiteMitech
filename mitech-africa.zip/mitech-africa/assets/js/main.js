/* M-ITECH AFRICA — scripts du site */
(function () {
  'use strict';

  /* Menu mobile */
  var burger = document.getElementById('burger');
  var menu = document.getElementById('menu');
  function closeMenu() {
    menu.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', 'Ouvrir le menu');
  }
  burger.addEventListener('click', function () {
    var open = menu.classList.toggle('is-open');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    burger.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  });
  menu.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', closeMenu); });

  /* En-tête + bouton retour en haut au défilement */
  var header = document.getElementById('header');
  var totop = document.getElementById('totop');
  function onScroll() {
    var y = window.scrollY;
    header.classList.toggle('is-scrolled', y > 10);
    totop.classList.toggle('is-visible', y > 600);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* Lien de menu actif selon la section visible */
  var links = Array.prototype.slice.call(document.querySelectorAll('.nav__link'));
  var sections = links.map(function (l) { return document.querySelector(l.getAttribute('href')); }).filter(Boolean);
  if ('IntersectionObserver' in window) {
    var navObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          links.forEach(function (l) { l.classList.toggle('is-active', l.getAttribute('href') === '#' + e.target.id); });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(function (s) { navObs.observe(s); });
  }

  /* Diaporama */
  var slides = Array.prototype.slice.call(document.querySelectorAll('.slide'));
  var dotsBox = document.getElementById('dots');
  var count = document.getElementById('count');
  var current = 0, timer = null, DELAY = 6000;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var dots = slides.map(function (s, i) {
    var b = document.createElement('button');
    b.className = 'hero__dot';
    b.type = 'button';
    b.setAttribute('aria-label', 'Diapositive ' + (i + 1));
    b.addEventListener('click', function () { go(i); restart(); });
    dotsBox.appendChild(b);
    return b;
  });
  function go(i) {
    current = (i + slides.length) % slides.length;
    slides.forEach(function (s, k) {
      var on = k === current;
      s.classList.toggle('is-active', on);
      s.setAttribute('aria-hidden', on ? 'false' : 'true');
      s.querySelectorAll('a').forEach(function (a) { a.tabIndex = on ? 0 : -1; });
    });
    dots.forEach(function (d, k) { d.setAttribute('aria-current', k === current ? 'true' : 'false'); });
    count.textContent = (current + 1) + ' / ' + slides.length;
  }
  function restart() {
    clearInterval(timer);
    if (!reduce) timer = setInterval(function () { go(current + 1); }, DELAY);
  }
  document.getElementById('prev').addEventListener('click', function () { go(current - 1); restart(); });
  document.getElementById('next').addEventListener('click', function () { go(current + 1); restart(); });
  var hero = document.getElementById('accueil');
  hero.addEventListener('mouseenter', function () { clearInterval(timer); });
  hero.addEventListener('mouseleave', restart);
  hero.addEventListener('focusin', function () { clearInterval(timer); });
  go(0);
  restart();

  /* Onglets des formations */
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.tab'));
  function selectTab(tab) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute('aria-controls')).hidden = !on;
    });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () { selectTab(t); });
    t.addEventListener('keydown', function (e) {
      var n = null;
      if (e.key === 'ArrowRight') n = tabs[(i + 1) % tabs.length];
      if (e.key === 'ArrowLeft') n = tabs[(i - 1 + tabs.length) % tabs.length];
      if (n) { e.preventDefault(); selectTab(n); n.focus(); }
    });
  });

  /* Boutons « S'inscrire » : présélectionne la formation dans le formulaire */
  var objet = document.getElementById('objet');
  document.querySelectorAll('[data-formation]').forEach(function (b) {
    b.addEventListener('click', function () { objet.value = b.getAttribute('data-formation'); });
  });

  /* Formulaire : ouvre la messagerie avec la demande rédigée */
  var form = document.getElementById('form');
  var err = document.getElementById('formError');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var ok = true;
    ['nom', 'tel', 'message'].forEach(function (id) {
      var f = document.getElementById(id);
      var bad = !f.value.trim();
      f.parentNode.classList.toggle('is-invalid', bad);
      f.setAttribute('aria-invalid', bad ? 'true' : 'false');
      if (bad) ok = false;
    });
    err.hidden = ok;
    if (!ok) return;
    var v = function (id) { return document.getElementById(id).value.trim(); };
    var body = 'Nom : ' + v('nom') + '\nTéléphone : ' + v('tel') + '\nE-mail : ' + v('email') +
      '\nDemande : ' + v('objet') + '\n\n' + v('message');
    window.location.href = 'mailto:info@mitech-africa.com?subject=' +
      encodeURIComponent('Demande via le site — ' + v('objet')) + '&body=' + encodeURIComponent(body);
  });

  /* Apparition des blocs au défilement */
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduce) {
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('is-visible'); obs.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (r) { obs.observe(r); });
  } else {
    reveals.forEach(function (r) { r.classList.add('is-visible'); });
  }

  /* Année du copyright */
  document.getElementById('year').textContent = new Date().getFullYear();
})();
