# Site web M-ITECH AFRICA

Site vitrine statique (HTML, CSS, JavaScript), sans base de données. Il fonctionne sur n'importe quel hébergement web.

## Contenu du dossier

```
mitech-africa/
├── index.html            la page du site
├── assets/css/style.css  la mise en forme (couleurs dans :root, en haut du fichier)
├── assets/js/main.js     menu mobile, diaporama, onglets, formulaire
└── assets/img/           logo.png, favicon.png (ajoutez vos photos ici)
```

## Mise en ligne

1. Connectez-vous à votre hébergeur (cPanel, FTP avec FileZilla…).
2. Envoyez **tout le contenu** du dossier `mitech-africa/` dans le dossier public du domaine (souvent `public_html/` ou `www/`).
3. Ouvrez www.mitech-africa.com : le site s'affiche.

## À compléter avant la mise en ligne

- **Réseaux sociaux** : dans `index.html`, remplacez les `href="#"` des liens Facebook, TikTok et Instagram par les adresses de vos pages (2 endroits : barre du haut et pied de page).
- **Photo « Qui sommes-nous »** : déposez `assets/img/equipe.jpg` et remplacez le bloc `about__placeholder` par
  `<img src="assets/img/equipe.jpg" alt="L'équipe M-ITECH AFRICA">` (une note l'indique dans le code).
- **Logo** : le fichier actuel contient la faute « TECHONOLOGIE ». Remplacez `assets/img/logo.png` par une version corrigée, même nom.

## Formulaire de contact

Le formulaire ouvre la messagerie du visiteur avec la demande déjà rédigée, adressée à info@mitech-africa.com. Aucun serveur n'est nécessaire.
Pour recevoir les messages sans passer par la messagerie du visiteur, branchez un service comme Formspree ou un script PHP de votre hébergeur.
